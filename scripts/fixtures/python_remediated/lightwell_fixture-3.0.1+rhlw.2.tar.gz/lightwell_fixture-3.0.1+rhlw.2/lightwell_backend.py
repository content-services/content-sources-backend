#!/usr/bin/env python3
"""Build synthetic Python packages using only the standard library."""

import ast
import base64
import gzip
import hashlib
import io
import sys
import tarfile
import zipfile
from pathlib import Path


PACKAGE_NAME = "lightwell-fixture"
MODULE_NAME = "lightwell_fixture"
VERSIONS = ("3.0.1+rhlw.1", "3.0.1+rhlw.2")


def metadata(version: str) -> bytes:
    return (
        "Metadata-Version: 2.1\n"
        f"Name: {PACKAGE_NAME}\n"
        f"Version: {version}\n"
        "Summary: Synthetic Lightwell remediated package\n"
    ).encode()


def wheel_metadata() -> bytes:
    return b"Wheel-Version: 1.0\nGenerator: lightwell-fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n"


def module_version(module: bytes) -> str:
    for statement in ast.parse(module.decode()).body:
        if isinstance(statement, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == "__version__"
            for target in statement.targets
        ):
            return ast.literal_eval(statement.value)
    raise ValueError("fixture module has no version")


def write_wheel(output_dir: Path, version: str, module: bytes) -> str:
    filename = f"{MODULE_NAME}-{version}-py3-none-any.whl"
    dist_info = f"{MODULE_NAME}-{version}.dist-info"
    files = {
        f"{MODULE_NAME}.py": module,
        f"{dist_info}/METADATA": metadata(version),
        f"{dist_info}/WHEEL": wheel_metadata(),
    }
    record_lines = []
    for path, contents in files.items():
        digest = base64.urlsafe_b64encode(hashlib.sha256(contents).digest()).rstrip(b"=").decode()
        record_lines.append(f"{path},sha256={digest},{len(contents)}\n")
    record_path = f"{dist_info}/RECORD"
    record_lines.append(f"{record_path},,\n")
    files[record_path] = "".join(record_lines).encode()

    output_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output_dir / filename, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, contents in files.items():
            entry = zipfile.ZipInfo(path, date_time=(1980, 1, 1, 0, 0, 0))
            entry.external_attr = 0o644 << 16
            archive.writestr(entry, contents, compress_type=zipfile.ZIP_DEFLATED)
    return filename


def write_sdist(output_dir: Path, version: str, module: bytes) -> str:
    filename = f"{MODULE_NAME}-{version}.tar.gz"
    prefix = f"{MODULE_NAME}-{version}"
    files = {
        "PKG-INFO": metadata(version),
        f"{MODULE_NAME}.py": module,
        "pyproject.toml": (
            '[build-system]\nrequires = []\nbuild-backend = "lightwell_backend"\n'
            'backend-path = ["."]\n'
        ).encode(),
        "lightwell_backend.py": Path(__file__).read_bytes(),
    }

    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / filename).open("wb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for path, contents in files.items():
                    entry = tarfile.TarInfo(f"{prefix}/{path}")
                    entry.size = len(contents)
                    entry.mode = 0o644
                    archive.addfile(entry, io.BytesIO(contents))
    return filename


def get_requires_for_build_wheel(config_settings=None):
    return []


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    module = Path(f"{MODULE_NAME}.py").read_bytes()
    version = module_version(module)
    dist_info = f"{MODULE_NAME}-{version}.dist-info"
    target = Path(metadata_directory) / dist_info
    target.mkdir(parents=True, exist_ok=True)
    (target / "METADATA").write_bytes(metadata(version))
    (target / "WHEEL").write_bytes(wheel_metadata())
    return dist_info


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    module = Path(f"{MODULE_NAME}.py").read_bytes()
    return write_wheel(Path(wheel_directory), module_version(module), module)


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: build_lightwell_python_fixture.py OUTPUT_DIR")

    output_dir = Path(sys.argv[1]).resolve()
    for version in VERSIONS:
        module = f"__version__ = '{version}'\n".encode()
        write_wheel(output_dir, version, module)
        write_sdist(output_dir, version, module)


if __name__ == "__main__":
    main()
